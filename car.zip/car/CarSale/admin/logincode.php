<?php include('security.php');?>

<?php include('database/dbconfig.php'); ?>

<?php
if(isset($_POST['loginbtn'])){

$email_login = $_POST['emaill'];
$password_login = $_POST['passwordd'];

$query = "SELECT * FROM user WHERE email='$email_login' AND password='$password_login'";
$query_run = mysqli_query($connection,$query);
$usertypes = mysqli_fetch_array($query_run);



if($usertypes['usertype'] == "admin")
{

 $_SESSION['username'] = $email_login;
 header('Location: ads.php');


}
else if($usertypes['usertype'] == "seller")
{

    $_SESSION['username'] = $email_login;
    header('Location: ../seller.php');

}
else if($usertypes['usertype'] == "customer")
{

    $_SESSION['username'] = $email_login;
    header('Location: ../home.php');

}
else{
    $_SESSION['status'] = "Email ID / Password is Incorrect";
    header('Location: ../login.php');
}
}

// End OF Login to Admin panel //
?>