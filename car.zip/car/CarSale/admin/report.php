<?php
include('security.php');
include('includes/header.php');
include('includes/navbar.php');  
?>
<!DOCTYPE html>
<html>
<head>
    <title>Convert Table to PDF using JavaScript</title>
    <style>
        table
        {
            width: 300px;
            font: 17px Calibri;
        }
        table, th, td 
        {
            border: solid 1px #DDD;
            border-collapse: collapse;
            padding: 2px 3px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div id="tab">
   


<div class="table-responsive">

<?php 


$query = "SELECT * FROM seller_ads";
$query_run = mysqli_query($connection, $query);


?>


    <table class="table table-bordered" id="tab" width="100%" collspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Edition</th>
                <th>Model Year</th>
                <th>Condition</th>
                <th>Mileage(Km)</th>
                <th>Transmission</th>
                <th>Fuel type</th>
                <th>Engine Capacity</th>
                <th>Description</th>
                <th>Image1</th>
                <th>Status</th>
                <th>Comments</th>
              
         
         
         


</tr>
</thead>
<tbody>


<?php 

 if(mysqli_num_rows($query_run)> 0){

    while($row = mysqli_fetch_assoc($query_run)){
?>


<tr>
    
    <td><?php  echo $row['id']; ?></td>
    <td><?php  echo $row['brand']; ?></td>
    <td><?php  echo $row['model']; ?></td>
    <td><?php  echo $row['edition']; ?></td>
    <td><?php  echo $row['model_year']; ?></td>
    <td><?php  echo $row['conditions']; ?></td>
    <td><?php  echo $row['mileage']; ?></td>
    <td><?php  echo $row['transmission']; ?></td>
    <td><?php  echo $row['fuel_type']; ?></td>
    <td><?php  echo $row['engine_capacity']; ?></td>
    <td><?php  echo $row['description']; ?></td>
    <td><?php echo'<img src="./upload/'.$row['image1'].'" width="100px;" height="100px;" alt="image">' ?></td>  
    <td><?php  echo $row['status']; ?></td>
    <td><?php  echo $row['comments']; ?></td>
    
   
 
    

   

</tr>


<?php
    }

 }  else{
     echo "No record found";
 } 
?>



</tbody>
</table>

                
</div>
    </div>
<div class="container text-center"><br>
    <p>
        <input type="button" value="Generate Report" 
            id="btPrint" onclick="createPDF()" />
    </p>
    </div>
</body>
<script>
    function createPDF() {
        var sTable = document.getElementById('tab').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 17px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CREATE A WINDOW OBJECT.
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Summary</title>');   // <title> FOR PDF HEADER.
        win.document.write(style);          // ADD STYLE INSIDE THE HEAD TAG.
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(sTable);         // THE TABLE CONTENTS INSIDE THE BODY TAG.
        win.document.write('</body></html>');

        win.document.close(); 	// CLOSE THE CURRENT WINDOW.

        win.print();    // PRINT THE CONTENTS.
    }
</script>
</html>

<?php

      include('includes/scripts.php');
      include('includes/footer.php'); 
?>
