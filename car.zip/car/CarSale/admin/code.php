<?php 
session_start();
include('database/dbconfig.php');



// Admin Register //

if(isset($_POST['registerbtn']))
 {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $usertype = $_POST['usertype'];

    if($password == $cpassword)
{


    $query = "INSERT INTO user (firstname,lastname,username,email,password,usertype) VALUES ('$firstname','$lastname','$username','$email','$password','$usertype')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "new profile added";
        header('Location: ../login.php');
    }
    else
    {
        $_SESSION['status22'] = "new profile is not added";
        header('Location: ../register.php');
    }

}
else
{
    $_SESSION['status22'] = "password and confirm password does not match";
    header('Location: ../register.php');

}
}









// END Admin Register //

//user Delete section //

if(isset($_POST['delete_btn_user'])){

    $id = $_POST['delete_id_user'];
    
    $query = "DELETE FROM user WHERE id='$id' ";
    $query_run = mysqli_query($connection,$query);


    if($query_run)
    {
        $_SESSION['success'] = "user is Deleted";
        header('Location: user.php');
    }
    else
    {
        $_SESSION['status'] = "user is Not Deleted";
        header('Location: user.php');
    }

}

//End of user delete section //

// Login to Admin panel //



// Logout to Admin panel //

if(isset($_POST['logoutbtns'])){


   session_destroy();
   unset($_SESSION['username']);
   header('Location: ../home.php');

}


if(isset($_POST['logoutbtn'])){


    session_destroy();
    unset($_SESSION['username']);
    header('Location: ../login.php');
 
 }


//End of  Logout to Admin panel //



// seller Ads crud//

// seller Ads insert//

if(isset($_POST['add_ads_btn']))
{
   

   $brand = $_POST['brand'];
   $model = $_POST['model'];
   $edition = $_POST['edition'];
   $model_year = $_POST['model_year'];
   $conditions = $_POST['conditions'];
   $mileage = $_POST['mileage'];
   $transmission = $_POST['transmission'];
   $fuel_type = $_POST['fuel_type'];
   $engine_capacity = $_POST['engine_capacity'];
   $price = $_POST['price'];
   $phone = $_POST['phone'];
   $description = $_POST['description'];
   $image1 = $_FILES["image1"]['name'];
   $image2 = $_FILES["image2"]['name'];
   $image3 = $_FILES["image3"]['name'];
   $status = $_POST['status'];

 
 
 

   $query = "INSERT INTO seller_ads (brand,model,edition,model_year,conditions,mileage,transmission,fuel_type,engine_capacity,price,phone,description,image1,image2,image3,status) VALUES ('$brand','$model','$edition','$model_year','$conditions','$mileage','$transmission','$fuel_type','$engine_capacity','$price','$phone','$description','$image1','$image2','$image3','$status')";
   $query_run = mysqli_query($connection, $query);

   if($query_run)
   {
       move_uploaded_file($_FILES["image1"]["tmp_name"], "upload/".$_FILES["image1"]["name"]);
       move_uploaded_file($_FILES["image2"]["tmp_name"], "upload/".$_FILES["image2"]["name"]);
       move_uploaded_file($_FILES["image3"]["tmp_name"], "upload/".$_FILES["image3"]["name"]);

   
       $_SESSION['success11'] = "ad added";
       header('Location: ../seller.php');
   }
   else
   {
       $_SESSION['status11'] = "ad not added";
       header('Location: ../seller.php');
   }



}

// END seller ads insert//


// seller ads updates //

if(isset($_POST['update_ads_btn']))
 {
    $edit_id = $_POST['edit_id'];
    $edit_brand = $_POST['edit_brand'];
    $edit_model = $_POST['edit_model'];
    $edit_edition = $_POST['edit_edition'];
    $edit_model_year = $_POST['edit_model_year'];
    $edit_conditions = $_POST['edit_conditions'];
    $edit_mileage = $_POST['edit_mileage'];
    $edit_transmission = $_POST['edit_transmission'];
    $edit_fuel_type = $_POST['edit_fuel_type'];
    $edit_engine_capacity = $_POST['edit_engine_capacity'];
    $edit_price = $_POST['edit_price'];
    $$edit_phone = $_POST['edit_phone'];
    $edit_description = $_POST['edit_description'];
    $edit_image1 = $_FILES["edit_image1"]['name'];
    $edit_image2 = $_FILES["edit_image2"]['name'];
    $edit_image3 = $_FILES["edit_image3"]['name'];
    $edit_status = $_POST['edit_status'];




 $query = "UPDATE seller_ads SET brand='$edit_brand',model='$edit_model',edition='$edit_edition',model_year='$edit_model_year',conditions='$edit_conditions',mileage='$edit_mileage',transmission='$edit_transmission',fuel_type='$edit_fuel_type',engine_capacity='$edit_engine_capacity',edit_price='$edit_price',edit_phone='$edit_phone',description='$edit_description',image1='$edit_image1', image2='$edit_image2',image3='$edit_image3',status='$edit_status' WHERE id='$edit_id'";
    $query_run = mysqli_query($connection,$query);


       if($query_run){
        move_uploaded_file($_FILES["edit_image1"]["tmp_name"], "upload/".$_FILES["edit_image1"]["name"]);
        move_uploaded_file($_FILES["edit_image2"]["tmp_name"], "upload/".$_FILES["edit_image2"]["name"]);
        move_uploaded_file($_FILES["edit_image3"]["tmp_name"], "upload/".$_FILES["edit_image3"]["name"]);
     
     
        $_SESSION['success11'] = "ads updated";
        header('Location: ../seller.php');


       }
       else
    {
        $_SESSION['status11'] = "ads not updated";
        header('Location: ../seller.php');
    }

 }


// seller ads updates //




// End Of seller ads deletes //

if(isset($_POST['delete_btn_seller'])){

    $id = $_POST['delete_id_seller'];
    
    $query = "DELETE FROM seller_ads WHERE id='$id' ";
    $query_run = mysqli_query($connection,$query);


    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Deleted";
        header('Location: ../seller.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Deleted";
        header('Location: ../seller.php');
    }

}
// seller ads deletes //

//admin ads deletes //

if(isset($_POST['delete_btn_admin'])){

    $id = $_POST['delete_id_admin'];
    
    $query = "DELETE FROM seller_ads WHERE id='$id' ";
    $query_run = mysqli_query($connection,$query);


    if($query_run)
    {
        $_SESSION['success1'] = "Your Data is Deleted";
        header('Location: ads.php');
    }
    else
    {
        $_SESSION['status1'] = "Your Data is Not Deleted";
        header('Location: ads.php');
    }

}



// End Of admin ads deletes //






// End of seller Ads crud//





// Ads Confirmation By Admin //

if(isset($_POST['confirm_ads_btn']))
 {
    $edit_id = $_POST['edit_id'];
    $edit_comment = $_POST['edit_comment'];
    $edit_status = $_POST['edit_status'];




 $query = "UPDATE seller_ads SET status='$edit_status',comments='$edit_comment' WHERE id='$edit_id'";
    $query_run = mysqli_query($connection,$query);


       if($query_run){
         
     
        $_SESSION['success1'] = "ads confirmation sucess";
        header('Location: ads.php');


       }
       else
    {
        $_SESSION['status1'] = "ads confirmation not sucessful";
        header('Location: ads.php');
    }

 }



// End Ads Confirmation by Admin //






//Feedback insert//


if(isset($_POST['add_ads_feedback']))
{
   

   $name = $_POST['name'];
   $email = $_POST['email'];
   $feedback = $_POST['feedback'];
   
 

   $query = "INSERT INTO feedback (name,email,feedback) VALUES ('$name','$email','$feedback')";
   $query_run = mysqli_query($connection, $query);

   if($query_run)
   {
   
      
       header('Location: ../home.php');
   }
 



}

// END of Feedbackinsert//


//notification insert//


if(isset($_POST['add_ads_notification']))
{
   


   $emails = $_POST['emails'];
  
   
 

   $query = "INSERT INTO notification (emails) VALUES ('$emails')";
   $query_run = mysqli_query($connection, $query);

   if($query_run)
   {
   
      
       header('Location: ../home.php');
   }
 



}

// END of notification//


?>








