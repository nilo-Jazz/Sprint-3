
<?php 

$server_name = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "carsale";

$connection = mysqli_connect($server_name, $db_username, $db_password);
$dbconfig = mysqli_select_db($connection,$db_name);

if($dbconfig){
   
}
else
{
    echo ' failed ';
}
?>






<?php 

//ads view page request by id database section//

$sql= "select * from seller_ads";
$query=mysqli_query($connection,$sql);



if(isset($_REQUEST['id'])){
    
    $id = $_REQUEST['id'];
    
    
    
    $sql = "select * from seller_ads where id = $id";
    $query = mysqli_query($connection,$sql);
    
   
    
}


//ads view page request by id database section//

?>




<?php 

//ads view page request by id database section//

$sqls= "select * from seller_ads";
$querys=mysqli_query($connection,$sqls);



if(isset($_REQUEST['brand'])){
    
    $brand = $_REQUEST['brand'];
    
    
    
    $sqls = "select * from seller_ads where brand = $brand";
    $querys = mysqli_query($connection,$sqls);
    
   
    
}


//ads view page request by id database section//

?>