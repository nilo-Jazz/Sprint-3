<?php include('security.php'); ?>
<?php include('includes/header.php');?>
<?php include('includes/navbar.php');?>









<div class="container-fluid">

<div class="card shadow mb-4">

<div class="card-header py-3">

<h6 class="m-0 font-weight-bold text-primary">ADS Updates </h6>

</div>


<div class="card-body">


<?php

if(isset($_POST['edit_btn_ads_confirm'])){

    $id = $_POST['edit_id_ads_confirm'];
   

    $query = "SELECT * FROM seller_ads WHERE id='$id' ";
    $query_run = mysqli_query($connection,$query);

    foreach($query_run as $row)
{

?>


<form action="code.php" method="POST" enctype="multipart/form-data">

<input type="hidden" name="edit_id" value="<?php echo $row['id'] ?>">


<div class="form-group">
<label>Status</label>
<select name="edit_status">

<option value="">--select--</option>
<option value="Accept">Accept</option>
<option value="Decline">Decline</option>

</select>
</div>


<div class="form-group">
          <label>Comments</label>
          <input type="text" name="edit_comment" class="form-control" placeholder="Enter comments"required>
     </div>

   




<a class="btn btn-danger" href="ads.php" >Cancel</a>
<button class="btn btn-primary" name="confirm_ads_btn" type="submit">update</button>

</form>


   <?php
     }
     }
     ?>           
</div>
</div>
</div>



<?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>