


<link rel="stylesheet" href="css/footer.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<!-- Footer --><br><br><br><br><br><br><br>
	<section id="footer">
	    <br>
		<div class="container">

		<h4 class="text-center">Quick links</h4>
			<div class="row text-center text-xs-center text-sm-left text-md-left">
			
				<div class="col-xs-12 col-sm-4 col-md-4 text-center">
				
					<ul class="list-unstyled quick-links">
						<li><a href="home.php"><i class="fa fa-angle-double-right"></i>Home</a></li>
						<li><a href="about.php"><i class="fa fa-angle-double-right"></i>About</a></li>
					
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4 text-center">
			
					<ul class="list-unstyled quick-links">
						<li><a href="privacy_policy.php"><i class="fa fa-angle-double-right"></i>Privacy Policy</a></li>
						<li><a href="Disclaimer.php"><i class="fa fa-angle-double-right"></i>Disclaimer</a></li>
						
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4 text-center">
					
					<ul class="list-unstyled quick-links">
						<li><a href="home.php"><i class="fa fa-angle-double-right"></i>CarRodio</a></li>
						<li><a href="contactus.php"><i class="fa fa-angle-double-right"></i>Contact US</a></li>
						
						
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href=""><i class="fab fa-facebook-square"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fab fa-twitter-square"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fab fa-google-plus-square"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fas fa-envelope"></i></a></li>
					</ul>
				</div>
				<hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
				    	
					<p><u><a href="#"></a></u></p>
					
					<p class="h6">© All right Reversed.<a class="text-green ml-2" href="home.php" target="_blank"></a></p>
				</div>
				<hr>
			</div>	
		</div>
	</section>

	<!-- ./Footer -->

</body>
</html>