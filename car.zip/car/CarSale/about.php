<?php include('includes/header.php');?>
<?php include('includes/navbar.php');?>





<section id="header" class="pad">
 <div class="container-fluid nav_bg">
  <div class="row">
   <div class="col-10 mx-auto">
    <div class="row">
     <div class="col-md-7 pt-5 pt-lg-0 order-2 order-lg-1 justify-content-center">

            <h1>About US</h1>
            <h4>About Car Rodio.lk</h4><hr>
            <div class="container-fluid">
            <p> Car Rodio.lk is a newly launched website coloborating with Car Rodio <br>
                Car Rodio.lk is a website featured for Cars exclusively <br>
                Car Rodio.lk is our online platform to target all sellers and customers to do transactions easily <br>
                Car Rodio was launched on 1/1/2018 <br>
                Car Rodio is launched on 20/6/2018 </p>
            </div>
                    
      </div>

             <div class="col-lg-4 order-1 order-lg-2 header-img">
                <img src="img/about.jpg" class="img-fluid animated" alt="home img"/>
             </div>
      </div>
     </div>
    </div>
   </div>
  </section> <br>

   

    <section>
     <div class="container-fluid nav_bg">
      <div class="row">
        <div class="col-10 mx-auto">
         <div class="row">

          <div class="col-md-6 pt-5 pt-lg-0 order-2 order-lg-2 justify-content-center">

            <h4>Why use car Rodio to buy and sell vehicles</h4><hr>
          <div class="container-fluid">
            <p> Car Rodio.lk offers almost all features you can use while doing transactions<br>

                Sellers can use our website to puclish and sell cars at a fast and easy rate<br>

                Customers can buy the featured cars from sellers easily<br>

                Customers can check with the sellers before car purchase </p>
           </div>
                    
          </div>

          <div class="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 justify-content-center">
                <h4>Quality Check</h4><hr>
                <div class="container-fluid">
                    <p> Compatible with almost all devices <br>

                        No experience issues guaranteed while transactions<br>

                        Live chat feed to present thoughts<br>

                        Adjust size according to the device</p>

                </div>
               </div>
              </div>
             </div>
            </div>
           </div>
         </section><br>







    <section>
     <div class="container-fluid nav_bg">
      <div class="row">
       <div class="col-10 mx-auto">
        <div class="row">
         <div class="col-md-6 pt-5 pt-lg-0 order-2 order-lg-2 justify-content-center">

             <h4>Quick and easy</h4><hr>
             <div class="container-fluid">
                <p>Quick login<br>
                   Easy to Register<br>
                   Fast transactions<br>
                   Easy search</p>
             </div>
            </div>

            <div class="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 justify-content-center">
              <h4>Contact Us</h4><hr>
            <div class="container-fluid">

            <p> Phone: 800-331-4331<br>
                       800-331-4332<br>

                Email: Car_Rodiolk@gmail.com<br>
                Fax: 333-111-22<br>
                the operator dial 1-800-331-4331</p>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
      </section><hr>






      <section>
       <div class="container-fluid nav_bg">
        <div class="row">
         <div class="col-10 mx-auto">
          <div class="row">
           <div class="col-md-5 pt-5 pt-lg-0 order-2 order-lg-2 justify-content-center"><br><br>
               
            <h4>Email</h4><hr>
            <div class="container-fluid">
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="your request">
            <button class="btn btn-outline-secondary" type="button">Email Us</button>
          </div>
         </div>
       </div>

         <div class="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 justify-content-center">
            <h1>Contact US</h1>
            <h4>Phone</h4><hr>
        <div class="container-fluid">

            <p> Phone: 800-331-4331B<br>

                Mon-Fri: 8:00a.m.-8:00p.m. ET<br>

                Sat: 8:00a.m.-5:30p.m. ET<br>

                TTY/TDD Users: Dial 711, then request<br>

                the operator dial 1-800-331-4331</p>

            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </section>



<?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>